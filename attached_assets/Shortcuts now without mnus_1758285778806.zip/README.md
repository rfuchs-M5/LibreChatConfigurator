# LibreChat Configuration

This package contains a complete LibreChat v0.8.0-rc3 installation with your custom configuration (using configuration schema v1.2.8).

## 📋 Package Contents

- `.env` - Environment variables configuration
- `librechat-config.yaml` - Main LibreChat configuration file
- `docker-compose.yml` - Docker services orchestration
- `install.sh` - Automated installation script
- `profile.json` - Configuration profile for easy re-import
- `README.md` - This documentation file

## 🚀 Quick Start

1. **Prerequisites**
   - Docker and Docker Compose installed
   - At least 4GB RAM and 10GB disk space
   - Open ports: 3080, 27017 (MongoDB)

2. **Installation**
   ```bash
   chmod +x install.sh
   ./install.sh
   ```

3. **Access**
   - Open your browser to: http://localhost:3080
   - Register an account (enabled)

## ⚙️ Configuration Summary

### Core Settings
- **LibreChat Version**: v0.8.0-rc3
- **Configuration Schema**: v1.2.8
- **Host**: 0.0.0.0:3080
- **Registration**: Enabled
- **Debug Logging**: Disabled

### AI Models
- **Default Model**: gpt-4
- **Model Selection UI**: Visible
- **Parameters UI**: Visible

### Features Enabled
- ✅ AI Agents
- ✅ Web Search
- ✅ File Search
- ✅ Presets
- ✅ Custom Prompts
- ✅ Bookmarks
- ❌ Memory System

### File Upload Settings
- **Max File Size**: 10MB
- **Max Files per Request**: 5
- **Allowed Types**: text/plain, application/pdf, image/jpeg, image/png, image/webp

### Rate Limits
- **Per User**: 100 requests
- **Per IP**: 500 requests
- **Uploads**: 50 per window
- **TTS**: 100 per window
- **STT**: 100 per window

### MCP Servers
- **the_megaphone**: streamable-http (https://7bec216a-1f3e-49b7-af7b-a730d84de27f-00-1b28s6q3zwadm.janeway.replit.dev)

## 🔧 Manual Configuration

### Environment Variables (.env)
Key security and application settings are stored in the `.env` file:
- JWT secrets for authentication
- Database credentials
- API keys
- Session timeouts

### LibreChat YAML (librechat-config.yaml)
The main configuration file controls:
- AI model endpoints
- UI feature visibility
- Agent capabilities
- File handling rules
- Rate limiting policies

### Profile File (profile.json)
A complete configuration profile that can be re-imported into the LibreChat Configuration Interface:
- Full configuration backup
- Easy re-loading for future modifications
- Compatible with the Profile → Import Profile feature

## 🐳 Docker Commands

### Basic Operations
```bash
# Start services
docker-compose up -d

# Stop services
docker-compose down

# Restart services
docker-compose restart

# View logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f librechat
```

### Maintenance
```bash
# Update images
docker-compose pull
docker-compose up -d

# Backup database
docker-compose exec mongodb mongodump --out /backup

# Clean up unused images
docker system prune -f
```

## 🔐 Security Notes

1. **Change Default Passwords**: Update MongoDB credentials in `.env`
2. **Secure API Keys**: Protect your OpenAI and other API keys
3. **JWT Secrets**: Use strong, unique JWT secrets (provided in config)
4. **Network Access**: Configure firewall rules for production use
5. **HTTPS**: Use a reverse proxy with SSL/TLS in production

## 🌐 Production Deployment

For production use, consider:

1. **Reverse Proxy**: Use Nginx or Caddy for HTTPS termination
2. **Domain Setup**: Configure proper domain name and SSL certificates
3. **Monitoring**: Set up log aggregation and monitoring
4. **Backups**: Regular database and configuration backups
5. **Updates**: Keep LibreChat and dependencies updated

## 📚 Additional Resources

- **LibreChat Documentation**: https://docs.librechat.ai
- **GitHub Repository**: https://github.com/danny-avila/LibreChat
- **Community Support**: https://discord.gg/uDyZ5Tzhct
- **Configuration Guide**: https://docs.librechat.ai/install/configuration

## 🆘 Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Change port in .env file
   PORT=3081
   ```

2. **Database Connection Issues**
   ```bash
   # Check MongoDB logs
   docker-compose logs mongodb
   ```

3. **Permission Errors**
   ```bash
   # Fix file permissions
   sudo chown -R $USER:$USER .
   ```

### Getting Help

If you encounter issues:
1. Check the logs: `docker-compose logs`
2. Verify your configuration files
3. Check the LibreChat documentation
4. Ask for help in the community Discord

---

**Generated on**: 2025-09-14
**LibreChat Version**: v0.8.0-rc3
**Configuration Schema**: v1.2.8
**Support**: https://docs.librechat.ai
